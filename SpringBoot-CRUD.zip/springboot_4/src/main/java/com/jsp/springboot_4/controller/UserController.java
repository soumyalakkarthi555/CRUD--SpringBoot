package com.jsp.springboot_4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.springboot_4.dao.UserDao;
import com.jsp.springboot_4.dto.User;

@RestController
public class UserController {

	@Autowired
	UserDao dao;

	@PostMapping("/save")
	public User saveStudent(@RequestBody User user) {

		return dao.save(user);
	}

	@GetMapping("/fetch")
	public User fetchUser(@RequestParam int id) {

		return dao.fethUserById(id);

	}

	@DeleteMapping("/delete")
	public User deleteUser(@RequestParam int id) {
		return dao.deleteById(id);
	}

	@PutMapping("/update")
	public User updateUser(@RequestBody User user) {

		return dao.UpdateById(user);
	}

	@GetMapping("/email")
	public User fetchUserByEmail(@RequestParam String email) {
		return dao.fetchUserByEmail(email);

	}
}
