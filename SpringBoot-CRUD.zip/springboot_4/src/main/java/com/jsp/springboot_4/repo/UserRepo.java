package com.jsp.springboot_4.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jsp.springboot_4.dto.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	@Query("select a from User a where email=?1")
	User findbyEmail(String email);
}
