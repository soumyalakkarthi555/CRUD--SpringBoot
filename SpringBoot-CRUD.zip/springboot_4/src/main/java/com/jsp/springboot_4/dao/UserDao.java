package com.jsp.springboot_4.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.springboot_4.dto.User;
import com.jsp.springboot_4.repo.UserRepo;

@Repository
public class UserDao {

	@Autowired

	UserRepo repo;

	public User save(User user) {
		repo.save(user);
		return user;
	}

	public User fethUserById(int id) {

		Optional<User> u = repo.findById(id);
		if (u.isPresent()) {
			return u.get();
		} else {
			return null;
		}
	}

	public User deleteById(int id) {
		Optional<User> u1 = repo.findById(id);
		if (u1.isPresent()) {
			User db = u1.get();
			repo.delete(db);
			return db;
		} else {
			return null;
		}

	}

	public User UpdateById(User user) {
		Optional<User> u1 = repo.findById(user.getId());
		if (u1.isPresent()) {
			return repo.save(user);
		} else {
			return null;
		}

	}

	public User fetchUserByEmail(String email) {

		return repo.findbyEmail(email);
	}
}
